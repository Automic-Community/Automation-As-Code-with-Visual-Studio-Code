# How to Use Automation-as-Code with the Visual Studio Code Editor

## Setup Visual Studio Code

Download Visual Code from here: [https://code.visualstudio.com/](https://code.visualstudio.com)

Install the VS Code REST-Client. To do so, search for "REST" in the Extension marketplace. Using this extension, you can interact directy with the Automic REST API within the VS Code editor.

![VS Code Rest Client](images/vs_code_rest_client.gif)  

## Create a New Folder an Add Git Support

We recommend that you create a folder where you store all your requests and template files. If you are using [git](https://git-scm.com/), you can also add this folder to your git repository. This would enable you to use version management for CDA or AWA entities.

```console
mkdir automation_as_code
cd automation_as_code
git init
```

![VS Code Create Folder](images/vs_code_add_folder.gif)

## Working with the REST Client

To use the VS Code Rest Client extension, you can either use the a template or you can create a new file with the extension .rest. Add the content provided below to the file. VS Code now knows that this is a REST API request and displays a Send Request button at the top of the window.
> You can find samples for AWA and CDA here:
> * [cda_api.rest](https://bitbucket.automic.com/stash/projects/TOOL/repos/automation-as-code/browse/vs_code/cda_api.rest)
> * [awa_api.rest](https://bitbucket.automic.com/stash/projects/TOOL/repos/automation-as-code/browse/vs_code/awa_api.rest)

A simple request to retrieve a list of CDA applications created on a specific system can be bound below. As soon as you add this command to the *.rest file it get's recognized by the REST extension and will add an "Send Request" command above.

```sh
GET http://localhost/cda/api/data/v1/applications
Authorization: Basic 100/AUTOMIC/AUTOMIC AUTOMIC
```

![VS Code Add Request](images/vs_code_add_new_request.gif)

If you want to add more than one request within a file, write three hashes '###' before each command. This indicates a new command.

```sh
### Retrieve all workflows
GET http://localhost/cda/api/data/v1/workflows HTTP/1.1
Authorization: Basic 100/AUTOMIC/AUTOMIC automic

### Retrieve single workflow
GET http://localhost/cda/api/data/v1/workflows/13562 HTTP/1.1
Authorization: Basic 100/AUTOMIC/AUTOMIC automic
```

Using this you can export and import CDA entities directly within the VS Code without having to swith to another tool. The REST Response can now be saved within your git repo, where you can then create new versions and manage your applications as JSON.

In addition to the calls, you can also specify variables which can be used to only define the credentials or often used parametres only once in top of the project.

## Find Below Samples for the Most Common API Calls

```sh
# Connection parameters
@endpoint = localhost:80/cda
@token = Basic 100/AUTOMIC/AUTOMIC AUTOMIC
@owner = "100/AUTOMIC/AUTOMIC"

### Retrieve all applications
GET http://{{endpoint}}/api/data/v1/applications HTTP/1.1
Authorization: {{token}}

### Duplicate existing application inlcuding components
POST http://{{endpoint}}/api/data/v1/applications/573/duplicate HTTP/1.1
Content-Type: application/json
Authorization: {{token}}

{
    "target_application": "DemoApp_v4",
    "target_owner": {{owner}}
}

### Export Application
GET http://{{endpoint}}/api/data/v1/applications/{{application_id}}/export HTTP/1.1
Authorization: {{token}}

### Import Application (json file below needs to be adapted)
POST http://{{endpoint}}/api/data/v1/applications/92700 HTTP/1.1
Content-Type: application/json
Authorization: {{token}}

< application_92700.json
```

![VS Code Create Folder](images/vs_code_sample.gif)